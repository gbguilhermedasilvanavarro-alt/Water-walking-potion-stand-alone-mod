package com.example.waterwalking;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;

public class WaterWalkEffect extends MobEffect {
    public WaterWalkEffect(MobEffectCategory category, int color) {
        super(category, color);
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public boolean applyEffectTick(LivingEntity entity, int amplifier) {
        // Faithful port of Cyclic 1.12.2's PotionWaterwalk logic.
        if (entity.level().getBlockState(entity.blockPosition().below()).is(Blocks.WATER)
                && entity.level().getBlockState(entity.blockPosition()).isAir()
                && entity.getDeltaMovement().y < 0.0D) {

            if (entity instanceof Player player && player.isShiftKeyDown()) {
                return true;
            }

            entity.setDeltaMovement(entity.getDeltaMovement().x, 0.0D, entity.getDeltaMovement().z);
            entity.setOnGround(true);
            entity.setFallDistance(0.1F);
        }

        return true;
    }
}
