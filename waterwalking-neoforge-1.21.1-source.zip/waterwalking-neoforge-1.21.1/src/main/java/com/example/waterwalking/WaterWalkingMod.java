package com.example.waterwalking;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.item.alchemy.PotionBrewing;
import net.minecraft.world.item.alchemy.Potions;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.brewing.RegisterBrewingRecipesEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(WaterWalkingMod.MOD_ID)
public class WaterWalkingMod {
    public static final String MOD_ID = "waterwalking";

    public static final DeferredRegister<MobEffect> MOB_EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, MOD_ID);

    public static final DeferredHolder<MobEffect, WaterWalkEffect> WATERWALK_EFFECT =
            MOB_EFFECTS.register("waterwalk", () ->
                    new WaterWalkEffect(MobEffectCategory.BENEFICIAL, 0x7FB8A4));

    public static final DeferredRegister<Potion> POTIONS =
            DeferredRegister.create(Registries.POTION, MOD_ID);

    public static final DeferredHolder<Potion, Potion> WATERWALK_POTION =
            POTIONS.register("waterwalk", registryName ->
                    new Potion(registryName.getPath(),
                            new MobEffectInstance(WATERWALK_EFFECT, 3600)));

    public WaterWalkingMod(IEventBus modEventBus) {
        MOB_EFFECTS.register(modEventBus);
        POTIONS.register(modEventBus);
        NeoForge.EVENT_BUS.register(BrewingHandler.class);
    }

    public static class BrewingHandler {
        @SubscribeEvent
        public static void registerBrewingRecipes(RegisterBrewingRecipesEvent event) {
            PotionBrewing.Builder builder = event.getBuilder();

            // Cyclic 1.12.2 ultimately made Waterwalking from its Snow potion base.
            // In 1.21.1 a Potion is a complete effect set rather than an inheriting type,
            // so the equivalent survival recipe is made directly from Awkward + Cod.
            builder.addMix(Potions.AWKWARD, Items.COD, WATERWALK_POTION);
        }
    }
}
